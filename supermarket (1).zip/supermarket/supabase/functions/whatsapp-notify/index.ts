// Edge Function: official WhatsApp Business Platform (Cloud API) notifications.
//
// Two modes (both are OPTIONAL and do nothing until you configure the secrets listed in docs/SETUP.md):
//   1) { order_number, token }        -> notify the STORE about a new order. Authorised by the order's secret token.
//   2) { order_id, to: "customer" }   -> notify the CUSTOMER about their order. Requires a signed-in owner/staff(orders).
//
// A wa.me link opened in a browser is NOT an API message. This function is the only thing that sets
// orders.whatsapp_api_status = 'sent', and only when Meta's API accepted the message.
// Secrets are read from Deno.env and are never returned to the client or logged.
import { createClient } from 'npm:@supabase/supabase-js@2.49.1';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Content-Type': 'application/json',
};
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: cors });

const STATUS_AR: Record<string, string> = {
  pending: 'بانتظار التأكيد', confirmed: 'تم التأكيد', preparing: 'جارٍ التجهيز',
  out_for_delivery: 'في الطريق إليك', completed: 'مكتمل', canceled: 'ملغي',
};
const waDigits = (p: string) => {
  let d = String(p || '').replace(/\D/g, '');
  if (d.startsWith('00')) d = d.slice(2);
  if (d.startsWith('0')) d = '20' + d.slice(1);
  return d;
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  if (req.method !== 'POST') return json({ sent: false, error: 'Method not allowed' }, 405);

  const TOKEN = Deno.env.get('WHATSAPP_TOKEN');
  const PHONE_ID = Deno.env.get('WHATSAPP_PHONE_NUMBER_ID');
  const LANG = Deno.env.get('WHATSAPP_TEMPLATE_LANG') ?? 'ar';
  if (!TOKEN || !PHONE_ID) {
    return json({ configured: false, sent: false, error: 'واتساب Cloud API غير مُهيّأ بعد (راجع docs/SETUP.md)' });
  }

  const url = Deno.env.get('SUPABASE_URL')!;
  const service = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, { auth: { persistSession: false } });

  let body: Record<string, string>;
  try { body = await req.json(); } catch { return json({ sent: false, error: 'طلب غير صالح' }, 400); }

  const { data: settings } = await service.from('store_settings').select('whatsapp_number,store_name,whatsapp_api_enabled').eq('id', 1).single();
  if (!settings?.whatsapp_api_enabled) return json({ configured: true, sent: false, error: 'الخاصية غير مفعّلة من إعدادات المتجر' });

  async function send(to: string, template: string, params: string[]) {
    const r = await fetch(`https://graph.facebook.com/v21.0/${PHONE_ID}/messages`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${TOKEN}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        messaging_product: 'whatsapp', to, type: 'template',
        template: { name: template, language: { code: LANG }, components: [{ type: 'body', parameters: params.map((text) => ({ type: 'text', text })) }] },
      }),
    });
    if (!r.ok) {
      const e = await r.json().catch(() => ({}));
      console.error('whatsapp api error', r.status, e?.error?.code); // no tokens / numbers in logs
      return { ok: false, error: e?.error?.message ?? `WhatsApp API ${r.status}` };
    }
    return { ok: true };
  }

  // ---- mode 1: store notification (guest-safe, token-authorised) ----
  if (body.order_number && body.token) {
    const { data: o } = await service.from('orders')
      .select('id,order_number,customer_name,total,whatsapp_api_status')
      .eq('order_number', body.order_number).eq('access_token', body.token).maybeSingle();
    if (!o) return json({ sent: false, error: 'الطلب غير موجود' }, 404);
    if (o.whatsapp_api_status === 'sent') return json({ configured: true, sent: true, already: true });
    const tpl = Deno.env.get('WHATSAPP_TEMPLATE_STORE');
    if (!tpl) return json({ configured: false, sent: false, error: 'WHATSAPP_TEMPLATE_STORE غير مضبوط' });
    const to = waDigits(Deno.env.get('WHATSAPP_STORE_RECIPIENT') ?? settings.whatsapp_number);
    const res = await send(to, tpl, [o.order_number, o.customer_name, String(o.total)]);
    await service.from('orders').update({ whatsapp_api_status: res.ok ? 'sent' : 'failed' }).eq('id', o.id);
    return json({ configured: true, sent: res.ok, error: res.ok ? undefined : res.error });
  }

  // ---- mode 2: customer notification (owner / staff with 'orders' permission only) ----
  if (body.order_id && body.to === 'customer') {
    const jwt = (req.headers.get('Authorization') ?? '').replace('Bearer ', '');
    const { data: u } = await service.auth.getUser(jwt);
    if (!u?.user) return json({ sent: false, error: 'غير مصرح' }, 401);
    const { data: roles } = await service.from('user_roles').select('role,permissions').eq('user_id', u.user.id);
    const allowed = (roles ?? []).some((r) => r.role === 'owner' || (r.role === 'staff' && r.permissions?.orders === true));
    if (!allowed) return json({ sent: false, error: 'غير مصرح' }, 403);
    const { data: o } = await service.from('orders').select('order_number,customer_name,customer_phone,status,total').eq('id', body.order_id).maybeSingle();
    if (!o) return json({ sent: false, error: 'الطلب غير موجود' }, 404);
    const tpl = Deno.env.get('WHATSAPP_TEMPLATE_CUSTOMER');
    if (!tpl) return json({ configured: false, sent: false, error: 'WHATSAPP_TEMPLATE_CUSTOMER غير مضبوط' });
    const res = await send(waDigits(o.customer_phone), tpl, [o.customer_name, o.order_number, STATUS_AR[o.status] ?? o.status, String(o.total)]);
    return json({ configured: true, sent: res.ok, error: res.ok ? undefined : res.error });
  }

  return json({ sent: false, error: 'طلب غير صالح' }, 400);
});
